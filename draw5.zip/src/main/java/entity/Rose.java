package entity;

public class Rose {
    private Integer size; // 大小

	public Integer getSize() {
		return size;
	}

	public void setSize(Integer size) {
		this.size = size;
	}

}